:mod:`{{module}}`.{{objname}}
{{ underline }}==============

.. meta::
   :robots: noindex

.. warning::
   **DEPRECATED**


.. currentmodule:: {{ module }}

.. autoclass:: {{ objname }}

.. include:: {{module}}.{{objname}}.examples

.. raw:: html

    <div class="clearer"></div>
